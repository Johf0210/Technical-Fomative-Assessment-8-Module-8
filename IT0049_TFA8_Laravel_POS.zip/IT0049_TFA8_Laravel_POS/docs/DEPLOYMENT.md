# GitHub and hosted-app submission

No repository or hosted app was created here. GitHub and hosting connections are
unavailable in this environment. Follow these steps after local setup/testing.

## Prepare the repository

Run `composer install`, `composer run setup`, and `composer test`. Check the
resource routes and browser flows. Commit the generated Breeze source and both
lock files. Include migrations and seeders. Exclude `.env`, dependencies, sessions,
logs, and local SQLite data using the supplied `.gitignore`.

Create an empty repository in your GitHub account, then replace the placeholder:

```sh
git init
git add .
git commit -m "Implement TFA8 resource controllers and Breeze authentication"
git branch -M main
git remote add origin <YOUR_ACTUAL_REPOSITORY_URL>
git push -u origin main
```

For an existing TFA7 repository, use a new branch there; do not reinitialize it or
replace its remote. The included GitHub Actions workflow runs setup and tests.
Inspect its actual result; a workflow file does not establish a successful check.

## Select hosting

Use PHP-capable hosting with PHP 8.2+, required extensions, a document root pointing
to `public/`, and writable persistent storage. Static hosting cannot run Laravel.
SQLite must be on persistent storage to retain data across deployments/restarts.

The included database config supports SQLite. For MySQL/PostgreSQL, add and test
the corresponding standard Laravel connection config first; changing just
`DB_CONNECTION` does not add the missing connection definition.

## Configure and deploy

Set private environment variables:

- `APP_ENV=production`, `APP_DEBUG=false`, and the real HTTPS `APP_URL`.
- A separate production `APP_KEY`, generated once and kept across deployments.
- `SESSION_SECURE_COOKIE=true` with HTTPS. Configure trusted proxies if needed
  by your host's HTTPS reverse proxy.
- An absolute `DB_DATABASE` path on persistent storage.
- Actual SMTP settings if email must be delivered outside the log.

Register your own account. Production seeding deliberately does not create the
local demo account.

With Breeze's generated source and lock files already committed, build assets
in your release/CI environment:

```sh
composer install --no-interaction --prefer-dist
npm ci
npm run build
```

If the host cannot build assets, upload the locally built `public/build` as a
release artifact. On the server after configuring the environment/database:

```sh
composer install --no-dev --no-interaction --prefer-dist --optimize-autoloader
php artisan migrate --force
php artisan optimize
```

Do not regenerate auth or the app key on each deployment. Never run
`migrate:fresh` on a live database. Configure the web server to serve `public/`;
`php artisan serve` is for local development.

Open the live URL from a logged-out browser. Verify login/registration, guest
redirects, and customer/user CRUD after login. Confirm the hosted revision matches
the GitHub submission. Add real URLs in `docs/SUBMISSION.md` and your submission
form. Include screenshots only after capturing real execution results.
