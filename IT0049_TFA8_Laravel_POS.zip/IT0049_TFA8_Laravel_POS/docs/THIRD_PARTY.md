# Framework and scaffolding

Laravel and Laravel Breeze are MIT-licensed projects by Taylor Otwell and their
contributors. Composer installs their packages and full licenses. This project
includes auth source following Breeze conventions; local setup refreshes the
auth/profile scaffold using the official installed Breeze generator.

Official source: [laravel/breeze](https://github.com/laravel/breeze).

Application-specific teaching code is under the root MIT license. This project
does not claim authorship of Laravel or Breeze. Run the actual installation and
tests before claiming a successful Breeze setup.
