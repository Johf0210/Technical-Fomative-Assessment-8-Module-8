# TFA8 submission information

**Student:** Johfreeh P. Fajardo  
**Course:** IT0049 — Web System Technologies  
**Activity:** TFA8 — Locking It Down  
**Section:** To be filled in  
**Professor:** To be filled in

## Required links

- **GitHub repository:** Pending — not created here.
- **Hosted working application:** Pending — not deployed here.

Replace both entries with genuine accessible URLs before submitting. A local
address such as http://127.0.0.1:8000 is not a hosted submission link.

## Implementation summary

Customer and user resource controllers each contain index, create, store, show,
edit, update, and destroy. Both resource registrations use authentication
middleware. Breeze provides login, registration, password recovery, and profile
management. Passwords are hashed, forms include CSRF fields, login regenerates
the session, and logout invalidates it. Migrations and local seed data are included.

## Completion checklist

- [x] Customer/user resource source, protected routes, and database files supplied.
- [x] Breeze dependency, auth source, and official-generator setup supplied.
- [x] Setup, integration, tests, and deployment instructions supplied.
- [ ] Refactor against the actual TFA7 source for continuity.
- [ ] Run Composer/Breeze/npm setup on a PHP-equipped machine.
- [ ] Run automated tests and record actual results.
- [ ] Verify guest/authenticated behavior in the browser.
- [ ] Publish raw source, generated Breeze files, and lock files to GitHub.
- [ ] Deploy, verify the live app, and fill in the required URLs.

Source is prepared. Unchecked items are not claimed as completed.
