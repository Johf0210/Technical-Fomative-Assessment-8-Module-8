# TFA8 manual test and evidence plan

Every manual case below is **not executed here**. Run the app and record actual
results, screenshots, and test dates.

| Case | Action | Expected result | Actual result |
| --- | --- | --- | --- |
| AC-01 | Logged out: /customers | Redirect to /login | Pending |
| AC-02 | Logged out: /users | Redirect to /login | Pending |
| AC-03 | Logged out: existing account edit URL | Redirect to /login | Pending |
| AC-04 | Login after requesting /customers | Return to /customers | Pending |
| AC-05 | Logged in: both management pages | Pages display normally | Pending |
| AC-06 | Create, view, edit, delete a customer | Actions succeed | Pending |
| AC-07 | Create, view, edit, delete another user | Actions succeed | Pending |
| AC-08 | Duplicate/malformed email | Validation error | Pending |
| AC-09 | Mismatched new user passwords | Validation error | Pending |
| AC-10 | Edit with blank password fields | Existing password retained | Pending |
| AC-11 | Logout, revisit protected URL | Redirect to /login | Pending |
| AC-12 | Register an account | Authenticated dashboard access | Pending |
| AC-13 | Five bad logins, then immediate correct login | Temporary throttling | Pending |

Capture actual `route:list --path=customers`, `route:list --path=users`, and
`composer test` output. Capture the same protected page before and after login,
both management lists, and a successful create/edit. Check the deployed app too.
Keep passwords, keys, SMTP credentials, and `.env` contents out of screenshots.
