# Applying this to your actual TFA7 POS

The original TFA7 code is not attached. This project demonstrates TFA8 separately;
it cannot prove your earlier fields, upload handling, validation, and relationships
were preserved. Supply that project ZIP or repository for the exact refactor.

1. Back up the database and create a git branch.
2. Keep current migrations, models, views, validation, and upload logic.
3. Install compatible Breeze dependencies with
   `composer require laravel/breeze --dev`, then `php artisan breeze:install blade`.
4. Refactor customer/user actions into the seven conventional resource methods,
   keeping their original business behavior.
5. Replace manual CRUD routes with one resource registration per type, inside
   `Route::middleware('auth')->group(...)`.
6. Update form actions, redirects, and links to resource route names. Use CSRF
   fields and the appropriate PUT/DELETE method fields.
7. Keep existing migrations. Add only new migrations your actual database needs;
   do not run this standalone project's table-creation migrations over TFA7 data.
8. Test guest and authenticated access and rerun prior validation/upload checks.

The retained product/sale example came from this conversation. It does not replace
the unattached TFA7 application.
