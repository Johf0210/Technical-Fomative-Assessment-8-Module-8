<?php
namespace Database\Seeders;

use App\Models\Customer;
use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Classroom sample data is local/testing only. Production users register normally.
        if (! app()->environment(['local', 'testing'])) { return; }
        // Reseeding does not reset a changed password.
        User::firstOrCreate(['email' => 'cashier@example.test'], [
            'name' => 'iTam Cashier', 'password' => 'Classroom123!',
        ]);
        Customer::firstOrCreate(['email' => 'customer@example.test'], [
            'name' => 'Sample Customer', 'phone' => '09123456789', 'address' => 'Manila',
        ]);
        Product::firstOrCreate(['sku' => 'WATER-500'], [
            'name' => 'Bottled Water 500 mL', 'price_cents' => 2000,
            'stock' => 8, 'low_stock_threshold' => 5,
        ]);
        Product::firstOrCreate(['sku' => 'BREAD-001'], [
            'name' => 'Bread', 'price_cents' => 3500,
            'stock' => 20, 'low_stock_threshold' => 5,
        ]);
    }
}
