<?php
/** Run after composer install. This runs the REAL installed Breeze generator. */
$root = dirname(__DIR__);
chdir($root);
if (! file_exists('.env')) { copy('.env.example', '.env'); }
if (! file_exists('database/database.sqlite')) { touch('database/database.sqlite'); }
if (! is_file('vendor/autoload.php')) { fwrite(STDERR, "Run composer install first.\n"); exit(1); }
if (! is_file('vendor/laravel/breeze/stubs/default/routes/auth.php')) {
    fwrite(STDERR, "Breeze is missing. Run composer install WITH development dependencies.\n"); exit(1);
}

function runCommand(array $command): void
{
    $process = proc_open($command, [0 => STDIN, 1 => STDOUT, 2 => STDERR], $pipes);
    if (! is_resource($process) || proc_close($process) !== 0) {
        throw new RuntimeException('Command failed: '.implode(' ', $command));
    }
}

// Breeze replaces routes/web.php and a dashboard view. Keep our actual POS routes.
// A durable backup and finally block preserve them if the installer fails.
$routeFile = $root.'/routes/web.php';
$routeBackup = $root.'/storage/app/tfa8-web-routes.backup';
$marker = $root.'/storage/app/breeze-installed';

try {
    $envContents = file_get_contents('.env');
    if (! preg_match('/^APP_KEY=.+$/m', $envContents)) { runCommand([PHP_BINARY, 'artisan', 'key:generate', '--ansi']); }

    if (! file_exists($marker)) {
        if (file_exists($routeBackup)) {
            throw new RuntimeException('An interrupted install left storage/app/tfa8-web-routes.backup. Restore it to routes/web.php, remove the backup, then retry.');
        }
        $savedRoutes = file_get_contents($routeFile);
        file_put_contents($routeBackup, $savedRoutes);
        try {
            runCommand([PHP_BINARY, 'artisan', 'breeze:install', 'blade', '--no-interaction']);
        } finally {
            file_put_contents($routeFile, $savedRoutes);
            unlink($routeBackup);
        }
        file_put_contents($marker, date(DATE_ATOM)."\n");
    }
    runCommand([PHP_BINARY, 'artisan', 'optimize:clear']);
    runCommand([PHP_BINARY, 'artisan', 'migrate', '--seed']);
    echo "\nBreeze configured and POS routes restored. Run npm install, npm run build, then php artisan serve.\n";
} catch (Throwable $exception) {
    fwrite(STDERR, $exception->getMessage()."\n");
    exit(1);
}
