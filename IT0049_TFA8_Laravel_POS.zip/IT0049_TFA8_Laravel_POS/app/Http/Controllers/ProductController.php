<?php
namespace App\Http\Controllers;

use App\Http\Requests\ProductRequest;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class ProductController extends Controller
{
    public function index(): View
    {
        return view('products.index', ['products' => Product::orderBy('name')->get()]);
    }
    public function create(): View
    {
        return view('products.create', ['product' => new Product(['stock' => 0, 'low_stock_threshold' => 5])]);
    }
    public function store(ProductRequest $request): RedirectResponse
    {
        $product = Product::create($request->productData());
        return redirect()->route('products.show', $product)->with('status', 'Product created.');
    }
    public function show(Product $product): View
    {
        return view('products.show', compact('product'));
    }
    public function edit(Product $product): View
    {
        return view('products.edit', compact('product'));
    }
    public function update(ProductRequest $request, Product $product): RedirectResponse
    {
        $product->update($request->productData());
        return redirect()->route('products.show', $product)->with('status', 'Product updated.');
    }
    public function destroy(Product $product): RedirectResponse
    {
        // Soft deletion removes the product from inventory screens but preserves sale history.
        $product->delete();
        return redirect()->route('products.index')->with('status', 'Product deleted. Sale history was retained.');
    }
}
