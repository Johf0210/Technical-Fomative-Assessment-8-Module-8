<?php
namespace App\Http\Controllers;

use App\Http\Requests\CustomerRequest;
use App\Models\Customer;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class CustomerController extends Controller
{
    public function index(): View
    {
        return view('customers.index', ['customers' => Customer::orderBy('name')->get()]);
    }
    public function create(): View
    {
        return view('customers.create', ['customer' => new Customer]);
    }
    public function store(CustomerRequest $request): RedirectResponse
    {
        $customer = Customer::create($request->validated());
        return redirect()->route('customers.show', $customer)->with('status', 'Customer created.');
    }
    public function show(Customer $customer): View
    {
        return view('customers.show', compact('customer'));
    }
    public function edit(Customer $customer): View
    {
        return view('customers.edit', compact('customer'));
    }
    public function update(CustomerRequest $request, Customer $customer): RedirectResponse
    {
        $customer->update($request->validated());
        return redirect()->route('customers.show', $customer)->with('status', 'Customer updated.');
    }
    public function destroy(Customer $customer): RedirectResponse
    {
        $customer->delete();
        return redirect()->route('customers.index')->with('status', 'Customer deleted.');
    }
}
