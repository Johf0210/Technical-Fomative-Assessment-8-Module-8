<?php
namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class UserController extends Controller
{
    public function index(): View { return view('users.index', ['users' => User::orderBy('name')->get()]); }
    public function create(): View { return view('users.create', ['user' => new User]); }
    public function store(UserRequest $request): RedirectResponse
    {
        // User's hashed cast stores the password as a secure hash, never plaintext.
        $user = User::create($request->validated());
        return redirect()->route('users.show', $user)->with('status', 'User account created.');
    }
    public function show(User $user): View { return view('users.show', compact('user')); }
    public function edit(User $user): View { return view('users.edit', compact('user')); }
    public function update(UserRequest $request, User $user): RedirectResponse
    {
        $data = $request->validated();
        if (empty($data['password'])) { unset($data['password']); }
        $user->fill($data);
        if ($user->isDirty('email')) { $user->email_verified_at = null; }
        $user->save();
        return redirect()->route('users.show', $user)->with('status', 'User account updated.');
    }
    public function destroy(Request $request, User $user): RedirectResponse
    {
        if ($request->user()->is($user)) {
            throw ValidationException::withMessages(['user' => 'You cannot delete your own account from user management.']);
        }
        $user->delete();
        return redirect()->route('users.index')->with('status', 'User account deleted.');
    }
}
