<?php
namespace App\Http\Controllers;

use App\Mail\LowStockMail;
use App\Models\Product;
use App\Models\Sale;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class SaleController extends Controller
{
    public function index(): View
    {
        return view('sales.index', ['sales' => Sale::with(['product', 'user'])->latest('id')->get()]);
    }

    public function create(): View
    {
        return view('sales.create', ['products' => Product::orderBy('name')->get()]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', Rule::exists('products', 'id')->whereNull('deleted_at')],
            'quantity' => ['required', 'integer', 'min:1', 'max:1000000'],
        ]);

        // Either BOTH the inventory deduction and sale are saved, or NEITHER is saved.
        [$sale, $product, $crossedThreshold] = DB::transaction(function () use ($data, $request) {
            $product = Product::lockForUpdate()->findOrFail($data['product_id']);
            $oldStock = $product->stock;
            $quantity = (int) $data['quantity'];

            // The stock condition makes deduction atomic, including on SQLite where
            // lockForUpdate() does not provide a row lock. Failed deductions create no sale.
            $deducted = Product::whereKey($product->id)
                ->where('stock', '>=', $quantity)
                ->decrement('stock', $quantity);
            if ($deducted !== 1) {
                throw ValidationException::withMessages(['quantity' => 'Not enough stock for this sale.']);
            }

            // Price and cashier identity always come from the server.
            $sale = Sale::create([
                'product_id' => $product->id,
                'user_id' => $request->user()->id,
                'quantity' => $quantity,
                'unit_price_cents' => $product->price_cents,
                'total_cents' => $product->price_cents * $quantity,
            ]);
            $product->refresh();
            $crossed = $oldStock > $product->low_stock_threshold
                && $product->stock <= $product->low_stock_threshold;

            return [$sale, $product, $crossed];
        }, 3);

        // The transaction above has committed before any email is sent.
        $message = 'Sale #'.$sale->id.' recorded.';
        if ($crossedThreshold) {
            try {
                Mail::to(config('pos.manager_email'))->send(new LowStockMail(
                    $product->name, $product->sku, $product->stock,
                    $product->low_stock_threshold, $sale->id,
                ));
                $message .= ' Low-stock alert processed (check the configured mail destination).';
            } catch (\Throwable $exception) {
                report($exception);
                return redirect()->route('sales.index')
                    ->with('status', $message)
                    ->with('warning', 'The sale was saved, but the low-stock email failed. Tell the manager; do not record the sale again.');
            }
        }
        return redirect()->route('sales.index')->with('status', $message);
    }
}
