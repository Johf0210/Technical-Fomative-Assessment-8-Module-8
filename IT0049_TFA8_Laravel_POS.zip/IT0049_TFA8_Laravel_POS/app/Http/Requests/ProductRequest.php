<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProductRequest extends FormRequest
{
    public function authorize(): bool { return $this->user() !== null; }

    public function rules(): array
    {
        // Ignore only the route-bound model, never a product ID submitted by the client.
        $product = $this->route('product');
        $uniqueSku = Rule::unique('products', 'sku');
        if ($product) { $uniqueSku->ignore($product); }

        return [
            'name' => ['required', 'string', 'max:120'],
            'sku' => ['required', 'string', 'max:40', $uniqueSku],
            'price' => ['required', 'numeric', 'decimal:0,2', 'min:0.01', 'max:1000000'],
            'stock' => ['required', 'integer', 'min:0', 'max:1000000'],
            'low_stock_threshold' => ['required', 'integer', 'min:0', 'max:1000000'],
        ];
    }

    public function productData(): array
    {
        $data = $this->validated();
        // Convert the validated decimal string into integer centavos without float arithmetic.
        [$pesos, $centavos] = array_pad(explode('.', (string) $data['price'], 2), 2, '');
        $data['price_cents'] = (int) $pesos * 100 + (int) str_pad($centavos, 2, '0');
        unset($data['price']);
        return $data;
    }
}
