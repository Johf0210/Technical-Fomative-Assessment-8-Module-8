<?php
namespace App\Mail;

use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;

class LowStockMail extends Mailable
{
    // Scalars preserve the inventory snapshot at the time of the sale.
    public function __construct(
        public string $productName,
        public string $sku,
        public int $remainingStock,
        public int $threshold,
        public int $saleId,
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(subject: 'Low stock: '.$this->productName);
    }
    public function content(): Content
    {
        return new Content(view: 'mail.low-stock');
    }
}
