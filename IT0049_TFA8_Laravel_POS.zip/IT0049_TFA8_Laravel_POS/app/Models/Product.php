<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use SoftDeletes;

    protected $fillable = ['name', 'sku', 'price_cents', 'stock', 'low_stock_threshold'];
    protected function casts(): array
    {
        return ['price_cents' => 'integer', 'stock' => 'integer', 'low_stock_threshold' => 'integer'];
    }
    public function sales(): HasMany
    {
        return $this->hasMany(Sale::class);
    }
    public function formattedPrice(): string
    {
        return number_format($this->price_cents / 100, 2);
    }
}
