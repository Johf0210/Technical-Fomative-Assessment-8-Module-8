<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Sale extends Model
{
    protected $fillable = ['product_id', 'user_id', 'quantity', 'unit_price_cents', 'total_cents'];
    protected function casts(): array
    {
        return ['quantity' => 'integer', 'unit_price_cents' => 'integer', 'total_cents' => 'integer'];
    }
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class)->withTrashed();
    }
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
