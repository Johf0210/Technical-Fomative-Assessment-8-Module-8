<?php
return ['manager_email' => env('POS_MANAGER_EMAIL', 'manager@example.test')];
