<?php
namespace Tests\Feature;

use App\Mail\LowStockMail;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class PosTest extends TestCase
{
    // Do not wrap each test in a transaction: verify email sees a committed sale.
    use DatabaseMigrations;

    private function staff(): User
    {
        return User::create(['name' => 'Cashier', 'email' => 'cashier@example.test', 'password' => 'Classroom123!']);
    }
    private function product(array $overrides = []): Product
    {
        return Product::create(array_merge([
            'name' => 'Bottled Water', 'sku' => 'WATER-500',
            'price_cents' => 2000, 'stock' => 8, 'low_stock_threshold' => 5,
        ], $overrides));
    }
    private function productInput(array $overrides = []): array
    {
        return array_merge(['name' => 'Bread', 'sku' => 'BREAD-001', 'price' => '35.25', 'stock' => 20, 'low_stock_threshold' => 5], $overrides);
    }

    public function test_guests_cannot_access_any_product_or_sale_action(): void
    {
        $product = $this->product();
        foreach (['/products', '/products/create', '/products/'.$product->id, '/products/'.$product->id.'/edit', '/sales', '/sales/create'] as $url) {
            $this->get($url)->assertRedirect('/login');
        }
        $this->post('/products', $this->productInput())->assertRedirect('/login');
        $this->put('/products/'.$product->id, $this->productInput())->assertRedirect('/login');
        $this->delete('/products/'.$product->id)->assertRedirect('/login');
        $this->post('/sales', ['product_id' => $product->id, 'quantity' => 3])->assertRedirect('/login');
        $this->assertDatabaseCount('sales', 0);
        $this->assertSame(8, $product->fresh()->stock);
    }

    public function test_login_and_logout_work(): void
    {
        $user = $this->staff();
        $this->get('/login')->assertOk();
        $this->post('/login', ['email' => $user->email, 'password' => 'Classroom123!'])->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($user);
        $this->post('/logout')->assertRedirect('/');
        $this->assertGuest();
    }

    public function test_invalid_credentials_are_rejected(): void
    {
        $user = $this->staff();
        $this->post('/login', ['email' => $user->email, 'password' => 'wrong'])->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_all_product_resource_actions_work(): void
    {
        $this->actingAs($this->staff());
        $this->get('/products')->assertOk();
        $this->get('/products/create')->assertOk();
        $this->post('/products', $this->productInput())->assertRedirect();
        $product = Product::firstOrFail();
        $this->assertSame(3525, $product->price_cents);
        $this->get('/products/'.$product->id)->assertOk()->assertSee('Bread');
        $this->get('/products/'.$product->id.'/edit')->assertOk()->assertSee('35.25');
        $this->put('/products/'.$product->id, $this->productInput(['name' => 'Fresh Bread', 'price' => '40.05']))->assertRedirect();
        $this->assertSame(4005, $product->fresh()->price_cents);
        $this->delete('/products/'.$product->id)->assertRedirect('/products');
        $this->assertSoftDeleted('products', ['id' => $product->id]);
    }

    public function test_duplicate_sku_and_negative_stock_are_rejected(): void
    {
        $this->actingAs($this->staff());
        $product = $this->product();
        $this->post('/products', $this->productInput(['sku' => $product->sku, 'stock' => -1]))
            ->assertSessionHasErrors(['sku', 'stock']);
        $this->assertDatabaseCount('products', 1);
    }

    public function test_price_must_have_at_most_two_decimal_places(): void
    {
        $this->actingAs($this->staff());
        $this->post('/products', $this->productInput(['price' => '12.345']))->assertSessionHasErrors('price');
        $this->assertDatabaseCount('products', 0);
    }

    public function test_sale_uses_server_price_and_cashier_identity(): void
    {
        Mail::fake();
        $user = $this->staff();
        $product = $this->product();
        $this->actingAs($user)->post('/sales', [
            'product_id' => $product->id, 'quantity' => 2, 'total_cents' => 1, 'user_id' => 999,
        ])->assertRedirect('/sales');
        $this->assertDatabaseHas('sales', ['quantity' => 2, 'total_cents' => 4000, 'user_id' => $user->id]);
        $this->assertSame(6, $product->fresh()->stock);
        Mail::assertNothingSent();
    }

    public function test_low_stock_email_is_sent_only_after_commit(): void
    {
        $this->actingAs($this->staff());
        $product = $this->product();
        config(['pos.manager_email' => 'manager@example.test']);
        $snapshot = null;
        Mail::shouldReceive('to')->once()->with('manager@example.test')->andReturnSelf();
        Mail::shouldReceive('send')->once()->andReturnUsing(function (LowStockMail $mail) use (&$snapshot) {
            $snapshot = [DB::transactionLevel(), Sale::count(), $mail->remainingStock, $mail->threshold, $mail->sku];
        });
        $this->post('/sales', ['product_id' => $product->id, 'quantity' => 3])->assertRedirect('/sales');
        $this->assertSame([0, 1, 5, 5, 'WATER-500'], $snapshot);
        $this->assertSame(5, $product->fresh()->stock);
    }

    public function test_crossing_below_the_threshold_also_sends_email(): void
    {
        Mail::fake();
        $product = $this->product();
        $this->actingAs($this->staff())->post('/sales', ['product_id' => $product->id, 'quantity' => 4])->assertRedirect('/sales');
        Mail::assertSent(LowStockMail::class, fn ($mail) => $mail->remainingStock === 4);
    }

    public function test_sales_while_already_low_do_not_repeat_the_alert(): void
    {
        Mail::fake();
        $product = $this->product(['stock' => 5]);
        $this->actingAs($this->staff())->post('/sales', ['product_id' => $product->id, 'quantity' => 1])->assertRedirect('/sales');
        Mail::assertNothingSent();
        $this->assertSame(4, $product->fresh()->stock);
    }

    public function test_restocking_allows_a_new_threshold_crossing_alert(): void
    {
        Mail::fake();
        $product = $this->product();
        $this->actingAs($this->staff());
        $this->post('/sales', ['product_id' => $product->id, 'quantity' => 3]);
        $product->update(['stock' => 8]);
        $this->post('/sales', ['product_id' => $product->id, 'quantity' => 3]);
        Mail::assertSent(LowStockMail::class, 2);
    }

    public function test_overselling_creates_no_sale_and_sends_no_email(): void
    {
        Mail::fake();
        $product = $this->product();
        $this->actingAs($this->staff())->post('/sales', ['product_id' => $product->id, 'quantity' => 9])
            ->assertSessionHasErrors('quantity');
        $this->assertSame(8, $product->fresh()->stock);
        $this->assertDatabaseCount('sales', 0);
        Mail::assertNothingSent();
    }

    public function test_zero_and_negative_quantities_are_rejected(): void
    {
        Mail::fake();
        $product = $this->product();
        $this->actingAs($this->staff());
        foreach ([0, -1] as $quantity) {
            $this->post('/sales', ['product_id' => $product->id, 'quantity' => $quantity])->assertSessionHasErrors('quantity');
        }
        $this->assertSame(8, $product->fresh()->stock);
        $this->assertDatabaseCount('sales', 0);
        Mail::assertNothingSent();
    }

    public function test_failed_sale_insert_rolls_back_stock_and_sends_no_email(): void
    {
        Mail::fake();
        $product = $this->product();
        $this->actingAs($this->staff());
        Sale::creating(function () { throw new \RuntimeException('Simulated database failure'); });
        try {
            $this->withoutExceptionHandling()->post('/sales', ['product_id' => $product->id, 'quantity' => 3]);
            $this->fail('Expected the simulated insert failure.');
        } catch (\RuntimeException $exception) {
            $this->assertSame('Simulated database failure', $exception->getMessage());
        } finally {
            Sale::flushEventListeners();
        }
        $this->assertSame(8, $product->fresh()->stock);
        $this->assertDatabaseCount('sales', 0);
        Mail::assertNothingSent();
    }

    public function test_mail_failure_does_not_undo_a_saved_sale(): void
    {
        $product = $this->product();
        Mail::shouldReceive('to')->once()->andReturnSelf();
        Mail::shouldReceive('send')->once()->andThrow(new \RuntimeException('SMTP unavailable'));
        $this->actingAs($this->staff())->post('/sales', ['product_id' => $product->id, 'quantity' => 3])
            ->assertRedirect('/sales')->assertSessionHas('warning');
        $this->assertDatabaseCount('sales', 1);
        $this->assertSame(5, $product->fresh()->stock);
    }

    public function test_deleted_products_cannot_be_sold_and_old_sales_are_retained(): void
    {
        Mail::fake();
        $product = $this->product();
        $this->actingAs($this->staff());
        $this->post('/sales', ['product_id' => $product->id, 'quantity' => 1]);
        $this->delete('/products/'.$product->id);
        $this->post('/sales', ['product_id' => $product->id, 'quantity' => 1])->assertSessionHasErrors('product_id');
        $this->get('/sales')->assertOk()->assertSee('Bottled Water');
        $this->assertDatabaseCount('sales', 1);
    }

    public function test_sale_form_and_email_view_render(): void
    {
        $product = $this->product();
        $this->actingAs($this->staff())->get('/sales/create')->assertOk()->assertSee('Record a sale');
        $html = (new LowStockMail($product->name, $product->sku, 5, 5, 1))->render();
        $this->assertStringContainsString('Remaining stock:', $html);
        $this->assertStringContainsString('WATER-500', $html);
    }
}
