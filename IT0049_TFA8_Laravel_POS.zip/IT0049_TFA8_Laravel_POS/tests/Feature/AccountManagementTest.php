<?php
namespace Tests\Feature;

use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AccountManagementTest extends TestCase
{
    use DatabaseMigrations;
    private function staff(): User
    {
        return User::create(['name' => 'Cashier', 'email' => 'cashier@example.test', 'password' => 'Classroom123!']);
    }
    private function customer(array $overrides = []): Customer
    {
        return Customer::create(array_merge(['name' => 'Sample Customer', 'email' => 'customer@example.test', 'phone' => '09123456789', 'address' => 'Manila'], $overrides));
    }
    private function customerInput(array $overrides = []): array
    {
        return array_merge(['name' => 'New Customer', 'email' => 'newcustomer@example.test', 'phone' => '09123456789', 'address' => 'Manila'], $overrides);
    }
    private function userInput(array $overrides = []): array
    {
        return array_merge(['name' => 'New Staff', 'email' => 'newstaff@example.test', 'password' => 'NewPassword123!', 'password_confirmation' => 'NewPassword123!'], $overrides);
    }
    public function test_every_customer_and_user_route_requires_login(): void
    {
        $customer = $this->customer(); $user = $this->staff();
        foreach (['customers' => $customer->id, 'users' => $user->id] as $resource => $id) {
            foreach (["/$resource", "/$resource/create", "/$resource/$id", "/$resource/$id/edit"] as $url) {
                $this->get($url)->assertRedirect('/login');
            }
            $this->post('/'.$resource, [])->assertRedirect('/login');
            $this->put('/'.$resource.'/'.$id, [])->assertRedirect('/login');
            $this->patch('/'.$resource.'/'.$id, [])->assertRedirect('/login');
            $this->delete('/'.$resource.'/'.$id)->assertRedirect('/login');
        }
        $this->assertDatabaseCount('customers', 1); $this->assertDatabaseCount('users', 1);
    }
    public function test_logged_in_users_can_reach_all_account_pages(): void
    {
        $user = $this->staff(); $customer = $this->customer(); $this->actingAs($user);
        foreach (['/dashboard', '/customers', '/customers/create', '/customers/'.$customer->id, '/customers/'.$customer->id.'/edit', '/users', '/users/create', '/users/'.$user->id, '/users/'.$user->id.'/edit'] as $url) {
            $this->get($url)->assertOk();
        }
    }
    public function test_login_returns_the_user_to_the_original_protected_page(): void
    {
        $user = $this->staff();
        $this->get('/customers')->assertRedirect('/login');
        $this->post('/login', ['email' => $user->email, 'password' => 'Classroom123!'])->assertRedirect('/customers');
        $this->get('/customers')->assertOk();
    }
    public function test_customer_create_update_and_delete_work(): void
    {
        $this->actingAs($this->staff());
        $this->post('/customers', $this->customerInput())->assertRedirect();
        $customer = Customer::firstOrFail();
        $this->put('/customers/'.$customer->id, $this->customerInput(['name' => 'Updated Customer']))->assertRedirect();
        $this->assertSame('Updated Customer', $customer->fresh()->name);
        $this->delete('/customers/'.$customer->id)->assertRedirect('/customers');
        $this->assertDatabaseMissing('customers', ['id' => $customer->id]);
    }
    public function test_customer_validation_rejects_missing_name_invalid_email_and_duplicates(): void
    {
        $this->actingAs($this->staff()); $customer = $this->customer();
        $this->post('/customers', $this->customerInput(['name' => '', 'email' => 'bad']))->assertSessionHasErrors(['name','email']);
        $this->post('/customers', $this->customerInput(['email' => $customer->email]))->assertSessionHasErrors('email');
        $this->assertDatabaseCount('customers', 1);
    }
    public function test_user_password_is_hashed_and_never_shown(): void
    {
        $this->actingAs($this->staff());
        $this->post('/users', $this->userInput())->assertRedirect();
        $user = User::where('email', 'newstaff@example.test')->firstOrFail();
        $this->assertTrue(Hash::check('NewPassword123!', $user->password));
        $this->assertNotSame('NewPassword123!', $user->password);
        $this->get('/users/'.$user->id)->assertOk()->assertDontSee($user->password, false)->assertDontSee('NewPassword123!');
        $this->assertArrayNotHasKey('password', $user->toArray());
    }
    public function test_blank_update_password_keeps_existing_hash(): void
    {
        $user = $this->staff(); $hash = $user->password;
        $this->actingAs($user)->put('/users/'.$user->id, ['name' => 'Updated Cashier', 'email' => $user->email, 'password' => '', 'password_confirmation' => ''])->assertRedirect();
        $this->assertSame($hash, $user->fresh()->password);
    }
    public function test_user_update_can_set_a_new_confirmed_password(): void
    {
        $user = $this->staff();
        $this->actingAs($user)->put('/users/'.$user->id, $this->userInput(['email' => $user->email]))->assertRedirect();
        $this->assertTrue(Hash::check('NewPassword123!', $user->fresh()->password));
    }
    public function test_duplicate_user_email_and_unconfirmed_password_are_rejected(): void
    {
        $user = $this->staff(); $this->actingAs($user);
        $this->post('/users', $this->userInput(['email' => $user->email]))->assertSessionHasErrors('email');
        $this->post('/users', $this->userInput(['password_confirmation' => 'mismatch']))->assertSessionHasErrors('password');
        $this->assertDatabaseCount('users', 1);
    }
    public function test_other_user_can_be_deleted_but_current_user_is_protected(): void
    {
        $user = $this->staff(); $other = User::create($this->userInput()); $this->actingAs($user);
        $this->delete('/users/'.$user->id)->assertSessionHasErrors('user');
        $this->delete('/users/'.$other->id)->assertRedirect('/users');
        $this->assertDatabaseMissing('users', ['id' => $other->id]);
        $this->assertDatabaseHas('users', ['id' => $user->id]);
    }
    public function test_deleted_user_cannot_log_in(): void
    {
        $user = $this->staff(); $user->delete();
        $this->post('/login', ['email' => $user->email, 'password' => 'Classroom123!'])->assertSessionHasErrors('email');
        $this->assertGuest();
    }
    public function test_deleting_another_user_keeps_their_sale_history(): void
    {
        $staff = $this->staff();
        $other = User::create($this->userInput());
        $product = Product::create(['name' => 'Water', 'sku' => 'WATER', 'price_cents' => 2000, 'stock' => 7, 'low_stock_threshold' => 5]);
        $sale = Sale::create(['product_id' => $product->id, 'user_id' => $other->id, 'quantity' => 1, 'unit_price_cents' => 2000, 'total_cents' => 2000]);
        $this->actingAs($staff)->delete('/users/'.$other->id)->assertRedirect('/users');
        $this->assertDatabaseHas('sales', ['id' => $sale->id, 'user_id' => null]);
        $this->get('/sales')->assertOk()->assertSee('Deleted account');
    }
    public function test_registration_creates_a_hashed_account_and_authenticates(): void
    {
        $this->get('/register')->assertOk();
        $this->post('/register', $this->userInput())->assertRedirect('/dashboard');
        $user = User::where('email', 'newstaff@example.test')->firstOrFail();
        $this->assertAuthenticatedAs($user);
        $this->assertTrue(Hash::check('NewPassword123!', $user->password));
    }
    public function test_login_is_throttled_after_five_failed_attempts(): void
    {
        $user = $this->staff();
        for ($attempt=0; $attempt<5; $attempt++) {
            $this->post('/login', ['email' => $user->email, 'password' => 'incorrect'])->assertSessionHasErrors('email');
        }
        $this->post('/login', ['email' => $user->email, 'password' => 'Classroom123!'])->assertSessionHasErrors('email');
        $this->assertGuest();
    }
}
