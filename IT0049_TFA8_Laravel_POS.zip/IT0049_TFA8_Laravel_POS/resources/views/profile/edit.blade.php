<x-app-layout><h1>My profile</h1>@include('auth._errors')
<form class="card" method="POST" action="{{ route('profile.update') }}">@csrf @method('PATCH')
<label for="name">Name</label><input id="name" name="name" value="{{ old('name', $user->name) }}" required>
<label for="email">Email</label><input id="email" name="email" type="email" value="{{ old('email', $user->email) }}" required>
<button type="submit">Save profile</button></form>
<h2>Change password</h2><form class="card" method="POST" action="{{ route('password.update') }}">@csrf @method('PUT')
<label for="current_password">Current password</label><input id="current_password" name="current_password" type="password" required>
<label for="password">New password</label><input id="password" name="password" type="password" required>
<label for="password_confirmation">Confirm new password</label><input id="password_confirmation" name="password_confirmation" type="password" required>
<button type="submit">Update password</button></form>
<h2>Delete my account</h2><form class="card" method="POST" action="{{ route('profile.destroy') }}">@csrf @method('DELETE')
<label for="delete_password">Confirm current password</label><input id="delete_password" name="password" type="password" required>
<button class="danger" type="submit">Delete my account</button></form></x-app-layout>
