@extends('layouts.pos')
@section('content')
<h1>Edit user account</h1>
<form class="card" method="POST" action="{{ route('users.update', $user) }}">
    @method('PUT')
    @include('users._form')
</form>
@endsection
