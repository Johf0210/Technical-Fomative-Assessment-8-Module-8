@csrf
<label for="name">Name</label>
<input id="name" name="name" type="text" value="{{ old('name', $user->name) }}" maxlength="255" required>
<label for="email">Email</label>
<input id="email" name="email" type="email" value="{{ old('email', $user->email) }}" maxlength="255" required>
<label for="password">Password</label>
<input id="password" name="password" type="password" autocomplete="new-password" minlength="8" @required(! $user->exists)>
@if($user->exists)<p class="muted">Leave the password fields empty to keep the current password.</p>@endif
<label for="password_confirmation">Confirm password</label>
<input id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password" @required(! $user->exists)>
<button type="submit">Save user account</button> <a href="{{ route('users.index') }}">Cancel</a>
