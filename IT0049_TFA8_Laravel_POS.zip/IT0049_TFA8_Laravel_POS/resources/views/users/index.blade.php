@extends('layouts.pos')
@section('content')
<div class="heading"><h1>User accounts</h1><a class="button" href="{{ route('users.create') }}">Add user account</a></div>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Actions</th></tr></thead><tbody>
@forelse($users as $user)
<tr><td>{{ $user->name ?: "—" }}</td><td>{{ $user->email ?: "—" }}</td><td><a href="{{ route('users.show', $user) }}">View</a> · <a href="{{ route('users.edit', $user) }}">Edit</a></td></tr>
@empty<tr><td colspan="3">No records yet.</td></tr>@endforelse
</tbody></table></div>
@endsection
