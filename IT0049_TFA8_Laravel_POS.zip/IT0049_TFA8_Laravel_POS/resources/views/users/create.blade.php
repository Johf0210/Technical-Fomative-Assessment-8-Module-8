@extends('layouts.pos')
@section('content')
<h1>Add user account</h1>
<form class="card" method="POST" action="{{ route('users.store') }}">

    @include('users._form')
</form>
@endsection
