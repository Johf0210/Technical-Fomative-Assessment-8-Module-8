@extends('layouts.pos')
@section('content')
<h1>{{ $user->name }}</h1><dl class="card"><dt>Name</dt><dd>{{ $user->name ?: "—" }}</dd>
<dt>Email</dt><dd>{{ $user->email ?: "—" }}</dd>
</dl>
<p><a class="button" href="{{ route('users.edit', $user) }}">Edit user account</a></p>
@if(auth()->id() !== $user->id)
<form method="POST" action="{{ route('users.destroy', $user) }}" onsubmit="return confirm('Delete this record?')">
@csrf @method('DELETE')<button class="danger" type="submit">Delete user account</button></form>
@else<p class="muted">You are currently signed in to this account.</p>@endif
@endsection
