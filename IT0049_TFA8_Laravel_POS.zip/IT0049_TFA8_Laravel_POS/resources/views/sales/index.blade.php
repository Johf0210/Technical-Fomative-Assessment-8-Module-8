@extends('layouts.pos')
@section('content')
<div class="heading"><h1>Sales</h1><a class="button" href="{{ route('sales.create') }}">Record sale</a></div>
<div class="table-wrap"><table>
<thead><tr><th>Sale</th><th>Product</th><th>Quantity</th><th>Total (PHP)</th><th>Cashier</th><th>Date</th></tr></thead>
<tbody>
@forelse($sales as $sale)
<tr>
    <td>#{{ $sale->id }}</td><td>{{ $sale->product->name }}</td><td>{{ $sale->quantity }}</td>
    <td>{{ number_format($sale->total_cents / 100, 2) }}</td><td>{{ $sale->user?->name ?? 'Deleted account' }}</td>
    <td>{{ $sale->created_at->format('M d, Y H:i') }}</td>
</tr>
@empty<tr><td colspan="6">No sales recorded yet.</td></tr>@endforelse
</tbody></table></div>
@endsection
