@extends('layouts.pos')
@section('content')
<h1>Record a sale</h1>
<p>Choose one product and the quantity sold. The server calculates the total.</p>
<form class="card" method="POST" action="{{ route('sales.store') }}">
    @csrf
    <label for="product_id">Product</label>
    <select id="product_id" name="product_id" required>
        <option value="">Choose a product</option>
        @foreach($products as $product)
            <option value="{{ $product->id }}" @selected((string) old('product_id') === (string) $product->id)>
                {{ $product->name }} — PHP {{ $product->formattedPrice() }} — {{ $product->stock }} in stock
            </option>
        @endforeach
    </select>
    <label for="quantity">Quantity</label>
    <input id="quantity" name="quantity" type="number" min="1" max="1000000" step="1" value="{{ old('quantity', 1) }}" required>
    <button type="submit">Record sale</button>
</form>
@endsection
