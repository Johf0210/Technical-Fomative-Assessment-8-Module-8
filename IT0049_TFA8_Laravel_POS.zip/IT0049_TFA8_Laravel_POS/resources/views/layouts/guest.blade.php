<!DOCTYPE html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}"><title>{{ config('app.name') }}</title>
<link rel="stylesheet" href="{{ asset('app.css') }}">
</head><body><div class="container"><header><strong>iTam POS <small>TFA8 · Staff access</small></strong></header>
<main><div class="auth-wrap">{{ $slot }}</div></main></div></body></html>
