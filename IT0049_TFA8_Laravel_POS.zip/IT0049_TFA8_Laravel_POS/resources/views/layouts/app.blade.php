<!DOCTYPE html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}"><title>{{ config('app.name') }}</title>
<link rel="stylesheet" href="{{ asset('app.css') }}">
</head><body><div class="container"><header><strong>iTam POS</strong><nav>
<a href="{{ route('dashboard') }}">Dashboard</a><a href="{{ route('profile.edit') }}">My profile</a>
<form method="POST" action="{{ route('logout') }}">@csrf<button>Log out</button></form>
</nav></header><main>@isset($header){{ $header }}@endisset {{ $slot }}</main></div></body></html>
