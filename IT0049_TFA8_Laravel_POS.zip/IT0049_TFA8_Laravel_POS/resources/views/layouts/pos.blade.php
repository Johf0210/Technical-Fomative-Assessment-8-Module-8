<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'iTam POS')</title>
    <link rel="stylesheet" href="{{ asset('app.css') }}">
</head>
<body>
<div class="container">
    <header>
        <strong>iTam POS <small>TFA8 · Account management</small></strong>
        @auth
            <nav aria-label="Main navigation">
                <a href="{{ route('dashboard') }}">Dashboard</a>
                <a href="{{ route('customers.index') }}">Customers</a>
                <a href="{{ route('users.index') }}">User accounts</a>
                <a href="{{ route('products.index') }}">Products</a>
                <a href="{{ route('sales.index') }}">Sales</a>
                <a href="{{ route('profile.edit') }}">My profile</a>
                <form method="POST" action="{{ route('logout') }}">@csrf<button type="submit">Log out</button></form>
            </nav>
        @endauth
    </header>
    <main>
        @if(session('status'))<p class="success" role="status">{{ session('status') }}</p>@endif
        @if(session('warning'))<p class="warning" role="alert">{{ session('warning') }}</p>@endif
        @if($errors->any())
            <div class="error" role="alert"><strong>Please check the form:</strong>
                <ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
            </div>
        @endif
        @yield('content')
    </main>
</div>
</body>
</html>
