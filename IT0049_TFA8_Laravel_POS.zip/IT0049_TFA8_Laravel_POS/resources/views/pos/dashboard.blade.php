@extends('layouts.pos')
@section('content')
<p class="eyebrow">IT0049 · Technical Formative Assessment 8</p>
<h1>Welcome, {{ auth()->user()->name }}</h1>
<p>Manage store records from one place.</p>
<div class="stat-grid">
    <a class="stat" href="{{ route('customers.index') }}"><span>Customers</span><strong>{{ $customerCount }}</strong><small>Manage customer records →</small></a>
    <a class="stat" href="{{ route('users.index') }}"><span>User accounts</span><strong>{{ $userCount }}</strong><small>Manage staff accounts →</small></a>
    <a class="stat" href="{{ route('products.index') }}"><span>Products</span><strong>{{ $productCount }}</strong><small>Manage inventory →</small></a>
    <a class="stat" href="{{ route('sales.index') }}"><span>Sales</span><strong>{{ $saleCount }}</strong><small>View recorded sales →</small></a>
</div>
<p><a class="button" href="{{ route('customers.create') }}">Add customer</a> <a href="{{ route('users.create') }}">Add user account</a></p>
@endsection
