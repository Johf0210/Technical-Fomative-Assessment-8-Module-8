<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Low-stock alert</title></head><body>
<h1>Low-stock alert</h1>
<p>Sale #{{ $saleId }} has been recorded successfully.</p>
<p>Product: <strong>{{ $productName }}</strong> ({{ $sku }})</p>
<p>Remaining stock: <strong>{{ $remainingStock }}</strong></p>
<p>Low-stock limit: {{ $threshold }}</p>
<p>Please arrange restocking.</p>
<p><a href="{{ route('products.index') }}">Open inventory (staff login required)</a></p>
</body></html>
