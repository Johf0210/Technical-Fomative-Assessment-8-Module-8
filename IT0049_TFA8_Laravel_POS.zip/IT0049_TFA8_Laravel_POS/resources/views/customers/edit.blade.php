@extends('layouts.pos')
@section('content')
<h1>Edit customer</h1>
<form class="card" method="POST" action="{{ route('customers.update', $customer) }}">
    @method('PUT')
    @include('customers._form')
</form>
@endsection
