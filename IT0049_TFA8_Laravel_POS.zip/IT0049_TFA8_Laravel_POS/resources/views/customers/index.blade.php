@extends('layouts.pos')
@section('content')
<div class="heading"><h1>Customers</h1><a class="button" href="{{ route('customers.create') }}">Add customer</a></div>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Actions</th></tr></thead><tbody>
@forelse($customers as $customer)
<tr><td>{{ $customer->name ?: "—" }}</td><td>{{ $customer->email ?: "—" }}</td><td>{{ $customer->phone ?: "—" }}</td><td>{{ $customer->address ?: "—" }}</td><td><a href="{{ route('customers.show', $customer) }}">View</a> · <a href="{{ route('customers.edit', $customer) }}">Edit</a></td></tr>
@empty<tr><td colspan="5">No records yet.</td></tr>@endforelse
</tbody></table></div>
@endsection
