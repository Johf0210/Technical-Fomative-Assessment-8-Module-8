@csrf
<label for="name">Name</label>
<input id="name" name="name" type="text" value="{{ old('name', $customer->name) }}" maxlength="120" required>
<label for="email">Email</label>
<input id="email" name="email" type="email" value="{{ old('email', $customer->email) }}" maxlength="255" required>
<label for="phone">Phone</label>
<input id="phone" name="phone" type="text" value="{{ old('phone', $customer->phone) }}" maxlength="30" >
<label for="address">Address</label>
<input id="address" name="address" type="text" value="{{ old('address', $customer->address) }}" maxlength="255" >
<button type="submit">Save customer</button> <a href="{{ route('customers.index') }}">Cancel</a>
