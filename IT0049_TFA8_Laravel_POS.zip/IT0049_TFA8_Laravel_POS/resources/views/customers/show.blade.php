@extends('layouts.pos')
@section('content')
<h1>{{ $customer->name }}</h1><dl class="card"><dt>Name</dt><dd>{{ $customer->name ?: "—" }}</dd>
<dt>Email</dt><dd>{{ $customer->email ?: "—" }}</dd>
<dt>Phone</dt><dd>{{ $customer->phone ?: "—" }}</dd>
<dt>Address</dt><dd>{{ $customer->address ?: "—" }}</dd>
</dl>
<p><a class="button" href="{{ route('customers.edit', $customer) }}">Edit customer</a></p>
<form method="POST" action="{{ route('customers.destroy', $customer) }}" onsubmit="return confirm('Delete this record?')">
@csrf @method('DELETE')<button class="danger" type="submit">Delete customer</button></form>
@endsection
