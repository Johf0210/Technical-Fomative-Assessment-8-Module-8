@extends('layouts.pos')
@section('content')
<h1>Add customer</h1>
<form class="card" method="POST" action="{{ route('customers.store') }}">

    @include('customers._form')
</form>
@endsection
