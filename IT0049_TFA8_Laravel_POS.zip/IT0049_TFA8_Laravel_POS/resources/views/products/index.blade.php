@extends('layouts.pos')
@section('content')
<div class="heading"><h1>Products</h1><a class="button" href="{{ route('products.create') }}">Add product</a></div>
<div class="table-wrap"><table>
<thead><tr><th>Product</th><th>SKU</th><th>Price (PHP)</th><th>Stock</th><th>Actions</th></tr></thead>
<tbody>
@forelse($products as $product)
<tr>
    <td><a href="{{ route('products.show', $product) }}">{{ $product->name }}</a></td>
    <td>{{ $product->sku }}</td><td>{{ $product->formattedPrice() }}</td>
    <td>{{ $product->stock }} @if($product->stock <= $product->low_stock_threshold)<span class="badge">Low stock</span>@endif</td>
    <td><a href="{{ route('products.edit', $product) }}">Edit</a></td>
</tr>
@empty<tr><td colspan="5">No products yet.</td></tr>@endforelse
</tbody></table></div>
@endsection
