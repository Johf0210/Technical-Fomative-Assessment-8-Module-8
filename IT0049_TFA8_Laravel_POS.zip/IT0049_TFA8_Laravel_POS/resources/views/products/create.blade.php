@extends('layouts.pos')
@section('content')
<h1>Add product</h1>
<form class="card" method="POST" action="{{ route('products.store') }}">
    @include('products._form')
</form>
@endsection
