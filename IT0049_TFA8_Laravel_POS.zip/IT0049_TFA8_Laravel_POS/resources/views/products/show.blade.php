@extends('layouts.pos')
@section('content')
<h1>{{ $product->name }}</h1>
<dl class="card">
    <dt>SKU</dt><dd>{{ $product->sku }}</dd>
    <dt>Price</dt><dd>PHP {{ $product->formattedPrice() }}</dd>
    <dt>Stock</dt><dd>{{ $product->stock }}</dd>
    <dt>Low-stock limit</dt><dd>{{ $product->low_stock_threshold }}</dd>
</dl>
<p><a class="button" href="{{ route('products.edit', $product) }}">Edit product</a></p>
<form method="POST" action="{{ route('products.destroy', $product) }}" onsubmit="return confirm('Delete this product from the active inventory?')">
    @csrf @method('DELETE')
    <button class="danger" type="submit">Delete product</button>
</form>
@endsection
