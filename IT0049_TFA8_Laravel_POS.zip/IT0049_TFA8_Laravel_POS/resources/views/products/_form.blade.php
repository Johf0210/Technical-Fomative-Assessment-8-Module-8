@csrf
<label for="name">Product name</label>
<input id="name" name="name" value="{{ old('name', $product->name) }}" maxlength="120" required>
<label for="sku">SKU (unique product code)</label>
<input id="sku" name="sku" value="{{ old('sku', $product->sku) }}" maxlength="40" required>
<label for="price">Price (PHP)</label>
<input id="price" name="price" type="number" step="0.01" min="0.01" max="1000000" value="{{ old('price', $product->exists ? number_format($product->price_cents / 100, 2, '.', '') : '') }}" required>
<label for="stock">Stock quantity</label>
<input id="stock" name="stock" type="number" min="0" max="1000000" step="1" value="{{ old('stock', $product->stock) }}" required>
<label for="low_stock_threshold">Low-stock limit</label>
<input id="low_stock_threshold" name="low_stock_threshold" type="number" min="0" max="1000000" step="1" value="{{ old('low_stock_threshold', $product->low_stock_threshold) }}" required>
<p class="muted">A sale triggers an alert when stock moves from above this limit to this limit or below.</p>
<button type="submit">Save product</button>
<a href="{{ route('products.index') }}">Cancel</a>
