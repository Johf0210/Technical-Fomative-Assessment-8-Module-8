@extends('layouts.pos')
@section('content')
<h1>Edit product</h1>
<form class="card" method="POST" action="{{ route('products.update', $product) }}">
    @method('PUT')
    @include('products._form')
</form>
@endsection
