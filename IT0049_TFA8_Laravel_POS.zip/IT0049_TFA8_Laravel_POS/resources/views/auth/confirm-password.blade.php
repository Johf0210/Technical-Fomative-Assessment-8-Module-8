<x-guest-layout><h1>Confirm password</h1>@include('auth._errors')
<form class="card" method="POST" action="{{ route('password.confirm') }}">@csrf
<label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="current-password">
<button type="submit">Confirm</button></form></x-guest-layout>
