<x-guest-layout><h1>Forgot password</h1><p>Enter your email to request a password-reset link.</p>
@include('auth._errors')
<form class="card" method="POST" action="{{ route('password.email') }}">@csrf
<label for="email">Email</label><input id="email" name="email" type="email" value="{{ old('email') }}" required autofocus>
<button type="submit">Email password reset link</button></form></x-guest-layout>
