<x-guest-layout>
<h1>Staff login</h1><p>Sign in to manage customers, user accounts, and inventory.</p>
@include('auth._errors')
<form class="card" method="POST" action="{{ route('login') }}">@csrf
<label for="email">Email</label><input id="email" name="email" type="email" value="{{ old('email') }}" required autofocus autocomplete="username">
<label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="current-password">
<label><input class="checkbox" type="checkbox" name="remember" value="1"> Remember me</label>
<button type="submit">Log in</button><a href="{{ route('password.request') }}">Forgot password?</a>
</form><p>New staff member? <a href="{{ route('register') }}">Register an account</a></p>
</x-guest-layout>
