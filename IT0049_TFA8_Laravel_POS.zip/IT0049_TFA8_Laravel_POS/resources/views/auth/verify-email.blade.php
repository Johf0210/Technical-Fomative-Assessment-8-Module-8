<x-guest-layout><h1>Verify your email</h1><p>Use the verification link sent to your email address.</p>@include('auth._errors')
<form method="POST" action="{{ route('verification.send') }}">@csrf<button type="submit">Resend verification email</button></form>
<form method="POST" action="{{ route('logout') }}">@csrf<button type="submit">Log out</button></form>
</x-guest-layout>
