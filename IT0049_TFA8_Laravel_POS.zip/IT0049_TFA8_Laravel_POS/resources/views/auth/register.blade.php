<x-guest-layout>
<h1>Register</h1>@include('auth._errors')
<form class="card" method="POST" action="{{ route('register') }}">@csrf
<label for="name">Name</label><input id="name" name="name" value="{{ old('name') }}" required autofocus autocomplete="name">
<label for="email">Email</label><input id="email" type="email" name="email" value="{{ old('email') }}" required autocomplete="username">
<label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="new-password">
<label for="password_confirmation">Confirm password</label><input id="password_confirmation" name="password_confirmation" type="password" required autocomplete="new-password">
<button type="submit">Register</button><a href="{{ route('login') }}">Already registered?</a>
</form></x-guest-layout>
