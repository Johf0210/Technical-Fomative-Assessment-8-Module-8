# IT0049 — TFA8: Locking It Down

Customer and user account management using Laravel resource controllers,
Laravel Breeze authentication, and protected routes.

Prepared for **Johfreeh P. Fajardo**. Section and professor were not provided.

## Scope and submission status

This standalone TFA8 source project extends the POS example created in this
conversation. The original TFA5–TFA7 repository was not attached, so this is
**not a verified refactor of that earlier application**. See
[integration notes](docs/INTEGRATING_TFA7.md) before applying it to an existing
POS or database. Do not replace earlier work or its migrations wholesale.

The assignment requires a GitHub repository URL and a live application URL.
Those have **not** been created. Upload/deployment instructions and a
[submission checklist](docs/SUBMISSION.md) are included.

## Features

- Customer and user resource controllers with all seven conventional methods.
- One `Route::resource()` declaration per resource, inside `auth` middleware.
- Login, registration, password reset, confirmation, and profile pages.
- Login throttling, password hashing, CSRF protection, and session handling.
- Server-side validation, unique emails, and password confirmation.
- Dashboard, migrations, sample data, and account-access tests.
- Earlier product CRUD and sale-triggered low-stock mail example retained.

All registered users can manage the same store's records, as requested by the
activity. There is no manager/cashier role distinction in this assessment.

## Requirements

- PHP 8.2–8.4, Composer 2, Node.js 22.12+ within Node 22, and npm.
- PHP extensions: Ctype, cURL, DOM, Fileinfo, Filter, Hash, Mbstring, OpenSSL,
  PCRE, PDO, PDO SQLite, Session, Tokenizer, XML, and XMLWriter for PHPUnit.
- Internet access for Composer/npm dependency installation.
- Writable `storage`, `bootstrap/cache`, and `database` directories.

Laravel 12 is used for PHP 8.2 compatibility; Breeze 2.x supports it. The
assignment's controller and authentication requirements apply to this version.
This archive contains source, not downloaded `vendor` or `node_modules` folders.
The first install creates dependency lock files; commit both generated lock
files with your submission for reproducible subsequent installs.

## Install and run

Extract the ZIP and open a terminal in `IT0049_TFA8_Laravel_POS`:

```sh
composer install
composer run setup
php artisan serve
```

Open [the local application](http://127.0.0.1:8000).

Local sample account:

- Email: `cashier@example.test`
- Password: `Classroom123!`

You can also register through `/register`. Sample data is seeded only when
`APP_ENV` is `local` or `testing`; reseeding does not reset existing passwords.

### What setup does

`composer run setup` runs `scripts/setup.php`, then npm install/build. The PHP
script copies `.env.example` if needed, creates the SQLite file if missing,
generates a key if blank, and runs the **installed package's official command**:

```sh
php artisan breeze:install blade --no-interaction
```

It restores the TFA8 `routes/web.php` after Breeze generates its default routes,
so the customer, user, product, and sale routes remain registered. It then clears
caches and runs migrations/seeders. POS views live separately from Breeze layouts.

Authentication source and views are bundled so the project contains auth source
before setup. Setup refreshes the standard auth/profile files using the actual
Breeze package and builds its frontend. The official installer was **not run
in this creation environment** because PHP/Composer were absent. A dependency
declaration alone is not proof of a successful Breeze installation.

Setup writes `storage/app/breeze-installed` after scaffolding and does not
overwrite auth files on later runs. To regenerate deliberately, first commit
or back up auth customizations, remove that marker, and rerun setup. If an
interrupted process leaves `storage/app/tfa8-web-routes.backup`, restore it to
`routes/web.php`, remove the backup, then retry.

If Breeze's npm step fails because Node is missing, install Node, rerun setup,
then finish `npm install` and `npm run build`. The PHP CLI needs `proc_open`
enabled for setup. Do not run this local scaffolding script on a live application.

## Test access control manually

1. Log out and open `/customers`, `/customers/create`, and `/users` directly.
   Each must redirect to `/login`.
2. Log in. Login returns you to an originally requested protected page, or to
   the dashboard when there is no intended destination.
3. List, create, view, edit, and delete a practice customer.
4. Create a second staff account, view it, edit it, and delete it.
5. Confirm duplicate emails and malformed email addresses are rejected.
6. Edit a user with both password fields blank: the old password remains.
   Supply matching new passwords to change it.
7. Log out and repeat a protected URL request. Login must be required again.
8. Register a fresh account and open both management sections.

See [TEST_PLAN.md](docs/TEST_PLAN.md) for outcomes and evidence to capture.
User management blocks deleting your currently signed-in account. Breeze's
separate profile page retains password-confirmed self-deletion. Deleting another
account preserves its past sales; the nullable cashier reference displays
“Deleted account.” Passwords and hashes are never displayed in user views.

## Automated checks

After setup:

```sh
php artisan route:list --except-vendor
composer test
```

The archive contains 14 account-management tests and 17 product/sale tests.
Breeze adds its own authentication/profile tests during setup. Account tests
cover all protected customer/user actions, guest redirects, authenticated access,
intended-page login redirects, resource CRUD, email validation, hashed passwords,
password updates, registration, deleted-user login denial, and login throttling.
Tests use in-memory SQLite and fake/mock mail.

**Verification status:** PHP/Composer are absent here. Laravel, the Breeze
generator, npm compilation, PHPUnit, and browser access-control behavior have
not been executed. Structural checks are recorded in
[VERIFICATION.md](docs/VERIFICATION.md). Do not report unexecuted checks as passed.

## Project map

| Requirement | File |
| --- | --- |
| Resource registrations and protected routes | `routes/web.php` |
| Customer CRUD | `app/Http/Controllers/CustomerController.php` |
| User CRUD | `app/Http/Controllers/UserController.php` |
| Customer validation | `app/Http/Requests/CustomerRequest.php` |
| User validation | `app/Http/Requests/UserRequest.php` |
| Login/session handling | `app/Http/Controllers/Auth/AuthenticatedSessionController.php` |
| Login validation/throttling | `app/Http/Requests/Auth/LoginRequest.php` |
| Registration | `app/Http/Controllers/Auth/RegisteredUserController.php` |
| Auth route names | `routes/auth.php` |
| Account-access tests | `tests/Feature/AccountManagementTest.php` |
| Database structure and sample data | `database/migrations/`, `database/seeders/` |
| Actual Breeze setup | `scripts/setup.php` |

For each of `customers` and `users`, one resource declaration supplies:

| HTTP method | Resource path | Controller method | Purpose |
| --- | --- | --- | --- |
| GET | /resource | index | List records |
| GET | /resource/create | create | Show the add form |
| POST | /resource | store | Validate and save a record |
| GET | /resource/{record} | show | Show one record |
| GET | /resource/{record}/edit | edit | Show the edit form |
| PUT/PATCH | /resource/{record} | update | Validate and save changes |
| DELETE | /resource/{record} | destroy | Delete a record |

Replace `resource` with `customers` or `users`. No extra manual CRUD registrations
are needed.

## Database and mail

SQLite is configured. Migrations and seeders satisfy the database-file submission
option; no database export is needed. The bundled SQLite file is empty. Setup
creates its tables and local sample data. Remove an old `DB_DATABASE` value if
it points at another computer; the default path is `database/database.sqlite`.

The mailer defaults to `log`. Password reset and low-stock messages appear in
`storage/logs/laravel.log`, not an inbox. For test SMTP, update `MAIL_*` and
`POS_MANAGER_EMAIL` in `.env`, then run `php artisan config:clear`.

The retained water example starts at 8 units with a threshold of 5: selling 3
saves the sale and inventory change before triggering an email. Subsequent sales
while already low do not repeat it. Restocking above the threshold permits a
new alert. Mail failure does not undo a saved sale; staff receive a warning.

## GitHub and hosting

Follow [DEPLOYMENT.md](docs/DEPLOYMENT.md). Run setup and checks locally, then
commit generated Breeze source, `composer.lock`, and `package-lock.json`.
Do not commit `.env`, dependencies, sessions, logs, or a populated local database.
Supply actual repository and working hosted URLs in
[SUBMISSION.md](docs/SUBMISSION.md) before submitting.

## References

- [Resource controllers](https://laravel.com/docs/12.x/controllers#resource-controllers)
- [Authentication](https://laravel.com/docs/12.x/authentication)
- [Breeze source and license](https://github.com/laravel/breeze)
- [Breeze installation](https://laravel.com/docs/11.x/starter-kits#laravel-breeze)
- [Laravel deployment](https://laravel.com/docs/12.x/deployment)
