<?php
// No custom console commands are needed.
